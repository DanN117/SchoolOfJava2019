package com.endava.s03e01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S03e01Application {

	public static void main(String[] args) {
		SpringApplication.run(S03e01Application.class, args);
	}

}
