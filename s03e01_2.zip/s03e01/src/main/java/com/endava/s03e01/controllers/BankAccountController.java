package com.endava.s03e01.controllers;

import com.endava.s03e01.models.BankAccount;
import com.endava.s03e01.repositories.BankAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BankAccountController {

    private BankAccountRepository bankAccountRepository;

    @Autowired
    public BankAccountController() {
        this.bankAccountService =
    }

    @PostMapping(path = "/add/account")
    public void addBankAccount(@RequestBody BankAccount ba) {

    }
}
