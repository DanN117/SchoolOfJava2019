package com.endava.s03e01.repositories;

import com.endava.s03e01.models.BankAccount;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class BankAccountRepository {
    List<BankAccount> bankAccountList = new ArrayList<BankAccount>();

    public void addBankAccount (BankAccount ba) {
        bankAccountList.add(ba);

    }

    public List<BankAccount> getBankAccountList() {
        return bankAccountList;
    }
}
