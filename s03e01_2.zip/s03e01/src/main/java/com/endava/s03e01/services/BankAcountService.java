package com.endava.s03e01.services;

import com.endava.s03e01.models.BankAccount;
import com.endava.s03e01.repositories.BankAccountRepository;
import org.springframework.stereotype.Service;

@Service
public class BankAcountService {

    // ...

    public void addBankAccount(BankAccount ba) {
        if (ba != null && ba.getBalance() >= 0.f) {

        }
    }
}
