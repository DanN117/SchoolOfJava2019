package com.endava.s03e01.controllers;

import com.endava.s03e01.models.BankAccount;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class FirstController {

    @RequestMapping(path = "/locatie01/(pathname)", method = RequestMethod.GET)
    public ResponseEntity<String> firstGet (@PathVariable String pathName) {
        String value = "Welcome!" + pathName + "This is a Controller test.";

        ResponseEntity<String> responseEntity = new ResponseEntity<>(value, HttpStatus.OK);
        return  responseEntity;
    }

    @PostMapping(path = "/locatie01/mypost")
    public ResponseEntity<BankAccount> firstPost(@RequestBody BankAccount ba) {
        ba.setBalance(ba.getBalance() + 50);

        ResponseEntity<BankAccount> requestEntity = new ResponseEntity<>(ba, HttpStatus.OK);

        return requestEntity;
    }
}
