package com.endava.s08e01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S08e01Application {

	public static void main(String[] args) {
		SpringApplication.run(S08e01Application.class, args);
	}

}
