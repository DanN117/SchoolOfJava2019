package com.endava.SoJ16_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoJ162Application {

	public static void main(String[] args) {
		SpringApplication.run(SoJ162Application.class, args);
	}

}
