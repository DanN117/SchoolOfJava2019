package com.endava.s05e01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S05e01Application {

	public static void main(String[] args) {
		SpringApplication.run(S05e01Application.class, args);
	}

}
