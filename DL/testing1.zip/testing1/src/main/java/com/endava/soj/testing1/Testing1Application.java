package com.endava.soj.testing1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Testing1Application {

	public static void main(String[] args) {
		SpringApplication.run(Testing1Application.class, args);
	}

}
