package com.endava.SoJ16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoJ16Application {

	public static void main(String[] args) {
		SpringApplication.run(SoJ16Application.class, args);
	}

}
