import org.aspectj.lang.annotation.Aspect;

@Aspect
public class AOPExemple {


}
