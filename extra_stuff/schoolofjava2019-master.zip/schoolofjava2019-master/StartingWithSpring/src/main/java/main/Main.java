package main;

import beans.TransactionRepository;
import beans.TransactionService;
import config.ProjectConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
   //de refacut pentru un singur try si luat beanurile in 2 feluri
       /* try(AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(ProjectConfig.class)){

            //TransactionRepository transactionRepository=context.getBean(TransactionRepository.class);
            TransactionRepository transactionRepositoryPrototype2=context.getBean( "transactionRepository2",TransactionRepository.class);
            TransactionRepository transactionRepository1=context.getBean( "transactionRepository1", TransactionRepository.class);

            transactionRepositoryPrototype2.setNume("Prototype");
            System.out.println(transactionRepositoryPrototype2);
        }
        */

        try(AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(ProjectConfig.class)){

            //TransactionRepository transactionRepository=context.getBean(TransactionRepository.class);
       //     TransactionRepository transactionRepositoryPrototype2=context.getBean( "transactionRepository2",TransactionRepository.class);
         //   TransactionRepository transactionRepository1=context.getBean( "transactionRepository1", TransactionRepository.class);

          //  transactionRepositoryPrototype2.setNume("Prototype");
         //   transactionRepository1.setNume("Singleton");
          //  System.out.println(transactionRepositoryPrototype2);
          //  System.out.println(transactionRepository1);

            TransactionService transactionService=context.getBean(TransactionService.class);


            System.out.println(transactionService);

        }
    }
}
