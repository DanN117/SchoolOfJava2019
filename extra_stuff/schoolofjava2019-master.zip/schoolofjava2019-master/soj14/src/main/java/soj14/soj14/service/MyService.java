package soj14.soj14.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import soj14.soj14.entities.Person;
import soj14.soj14.repository.PersonRepository;

import java.util.List;

@Service
public class MyService {

    private final PersonRepository personRepository;

    @Autowired
    public MyService(PersonRepository personRepository){
        this.personRepository=personRepository;
    }

    public List<Person> getPeople(){
        return personRepository.findAll();
    }

    public Person saveNewPerson(Person person){
        return personRepository.save(person);
    }

    public void deletePersonById(int id){
        personRepository.deleteById(id);
    }



}
