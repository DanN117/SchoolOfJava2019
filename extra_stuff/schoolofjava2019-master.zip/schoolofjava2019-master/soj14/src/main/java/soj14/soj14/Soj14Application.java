package soj14.soj14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Soj14Application {

	public static void main(String[] args) {
		SpringApplication.run(Soj14Application.class, args);
	}

}
