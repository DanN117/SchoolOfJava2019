package soj14.soj14.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import soj14.soj14.entities.Person;
import soj14.soj14.service.MyService;

import java.util.List;

@RestController
public class MyController {

    private final MyService myService;

    @Autowired
    public MyController(MyService myService){
        this.myService=myService;
    }

    @GetMapping("/getPeople")
    //public List<Person> getPeople(){
      public ResponseEntity<List<Person>> getPeople(){
        return ResponseEntity.ok(myService.getPeople());
    }

    @PostMapping("/addNewPerson")
    public Person addNewPerson(@RequestBody Person person){
        return myService.saveNewPerson(person);
    }

    @DeleteMapping("/deletePerson/{id}")
    public void deletePersonById(@PathVariable int id){
        myService.deletePersonById(id);
    }

}
