package soj7mapping.soj7mapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Soj7mappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(Soj7mappingApplication.class, args);
	}

}
