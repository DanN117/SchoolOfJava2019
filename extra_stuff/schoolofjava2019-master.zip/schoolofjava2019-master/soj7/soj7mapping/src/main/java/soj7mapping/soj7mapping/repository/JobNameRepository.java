package soj7mapping.soj7mapping.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import soj7mapping.soj7mapping.entities.JobName;

@Repository
public interface JobNameRepository extends JpaRepository<JobName, Integer> {

}
