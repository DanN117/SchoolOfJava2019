package soj7mapping.soj7mapping.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import soj7mapping.soj7mapping.entities.Person;
import soj7mapping.soj7mapping.service.MyService;

import java.util.List;

@RestController
public class MyController {

    private final MyService myService;

    public MyController(MyService myService){
        this.myService=myService;
    }

    @GetMapping(path="/getPeople")
    public List<Person> getPeople(){
        return myService.getPeople();
    }
}
