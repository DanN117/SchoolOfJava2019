package soj7.soj7.pk;

import java.io.Serializable;

public class DogPk implements Serializable {
    private int id;
    private int age;
}
