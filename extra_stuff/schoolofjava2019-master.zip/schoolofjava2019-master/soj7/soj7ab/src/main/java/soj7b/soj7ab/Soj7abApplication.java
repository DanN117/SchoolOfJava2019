package soj7b.soj7ab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Soj7abApplication {

	public static void main(String[] args) {
		SpringApplication.run(Soj7abApplication.class, args);
	}

}
