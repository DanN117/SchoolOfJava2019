package soj7b.soj7ab.entities;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class ParentEntity {
    private int age;
}
