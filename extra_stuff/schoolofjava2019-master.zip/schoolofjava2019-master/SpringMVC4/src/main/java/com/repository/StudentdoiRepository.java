package com.repository;

import com.model.Studentdoi;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentdoiRepository {
    private List<Studentdoi> studentList;

    public void addStudent(Studentdoi studentdoi){
        studentList.add(studentdoi);
    }
    public Studentdoi findById(int id){
        for(Studentdoi st:studentList){
            if(st.getId()==id){
                return st;
            }
        }
        System.out.println("The id has not been found");
        return null;

    }
    public List<Studentdoi> getList(){
        return studentList;
    }

}
