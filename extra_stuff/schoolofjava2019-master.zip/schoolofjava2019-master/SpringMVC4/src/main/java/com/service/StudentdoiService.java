package com.service;

import com.model.Student;
import com.model.Studentdoi;
import com.repository.StudentdoiRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentdoiService {
    private StudentdoiRepository studentdoiRepository;

    @Autowired
    StudentdoiService(StudentdoiRepository studentdoiRepository){
        this.studentdoiRepository=studentdoiRepository;
    }

    public void addStudent(Studentdoi studentdoi){
        studentdoiRepository.addStudent(studentdoi);
    }
    public Studentdoi findById(int id){
        return studentdoiRepository.findById(id);
    }
    public List<Studentdoi> getList(){
        return studentdoiRepository.getList();
    }


}
