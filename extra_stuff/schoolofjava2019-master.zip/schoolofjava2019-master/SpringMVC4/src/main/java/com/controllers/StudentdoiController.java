package com.controllers;

import com.model.Student;
import com.model.Studentdoi;
import com.service.StudentdoiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class StudentdoiController {
     private StudentdoiService studentdoiService;
     @Autowired
     StudentdoiController(StudentdoiService studentdoiService){
         this.studentdoiService=studentdoiService;
     }


     @RequestMapping(value="/studentdoi/add" , method=RequestMethod.POST)
     public String studentdoi(Model model, @RequestParam("id") int id, @RequestParam
             ("name") String name){
         Studentdoi st=new Studentdoi();
         st.setNume(name);
         st.setId(id);
         studentdoiService.addStudent(st);
         model.addAttribute("result", st.getNume() + ":  " + st.getId());
         return "studentdoi";
     }

     @RequestMapping(value="/studentdoi/getList", method=RequestMethod.GET)
     public String studentdoi(Model model){

         for(Studentdoi st:studentdoiService.getList()){
             model.addAttribute("result", st);
         }
         return "result";

     }
     @RequestMapping(value="/studentdoi/getById", method=RequestMethod.GET)
    public String studentdoi(Model model, @RequestParam("id") int id){
         model.addAttribute("result", studentdoiService.findById(id));
         return "result";
     }








}
