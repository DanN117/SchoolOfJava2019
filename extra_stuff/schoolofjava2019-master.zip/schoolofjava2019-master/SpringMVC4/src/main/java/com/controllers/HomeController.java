package com.controllers;

import com.model.Student;
import com.model.Studentdoi;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController {

    @RequestMapping(value="/home", method = RequestMethod.GET)
    public String printMyFirstProgram(ModelMap model) {
        model.addAttribute("message", "My First Program");
        return "home";
    }

    @RequestMapping(value="/student/details", method = RequestMethod.GET)
    public String student(ModelMap model) {
        Student st = new Student("Mihai", "Poli");
        model.addAttribute("student", st);

        return "student";
    }


    @RequestMapping(value = "/student/add", method = RequestMethod.POST)
    public String student(Model model, @RequestParam("name") String name, @RequestParam("college") String college) {
        model.addAttribute("result", name + ": " + college);
        return "student";
    }






}
