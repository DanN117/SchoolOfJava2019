import org.aopalliance.intercept.Joinpoint;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;

@Aspect
public class AOPExemple {

   /* @Pointcut("execution (* Student.display())")
    public void searchMethod(){

    }
    @Before("searchMethod()")
    public void logBefore(JoinPoint joinPoint) throws Throwable{
        System.out.println(joinPoint.getSignature().getName() + " " +joinPoint.getArgs().length);
    }

    @Before("execution(* Student.*(..))")
        public void logBefore1(JoinPoint jp)throws  Throwable{
            System.out.println(jp.getSignature().getName());
        }

    @After("searchMethod()")
    public void logAfter(JoinPoint jp1){
        System.out.println(jp1.getSignature().getName());

    }
    @After("execution(* Student.*(..))")
    public void logAfter2(JoinPoint jp2){
        System.out.println(jp2.getSignature().getName());
    }
    @Pointcut("execution (* Student.display())")
    public void methodAround(){

    }

    @Around("searchMethod() && methodAround()")
    public void logAround(ProceedingJoinPoint jp3)throws Throwable{
        System.out.println(jp3.getSignature().getName());
        jp3.proceed();
        System.out.println("blablablabla  " +jp3.getArgs().length);
    }
*/
    @Around ("execution(* Student.*(..)) ||  execution (* Student.*())")
    public void ceva (ProceedingJoinPoint proceedingJoinPoint) throws Throwable{
        System.out.println(proceedingJoinPoint.getSignature().getName());
        proceedingJoinPoint.proceed();
        System.out.println("alabalaportocala " +proceedingJoinPoint.getArgs().length);
    }

}
