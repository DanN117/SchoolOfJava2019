package soj12.soj12_v2.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import soj12.soj12_v2.entities.User;
import soj12.soj12_v2.repositories.UserRepository;

public class JpaUserDetailService implements UserDetailsService {
    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        User u=userRepository.findUserByUsername(s);
        if(u==null) throw new UsernameNotFoundException("User has not been found");

        return new JpaUserDetails(u);
    }
}
