package soj9.noSQLTest.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import soj9.noSQLTest.model.Movie;

@Repository
public interface MovieRepository extends MongoRepository<Movie,String> {
}
