package soj9.noSQLTest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import soj9.noSQLTest.model.Cast;
import soj9.noSQLTest.model.Movie;
import soj9.noSQLTest.repository.MovieRepository;

import java.util.List;

@Service
public class MovieService {
    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private CastService castService;
    public Movie add(Movie movie){
        Cast cast=castService.save(movie.getCast());
        return movieRepository.save(movie);

    }

    public List<Movie> findAll(){
        return movieRepository.findAll();
    }

}
