package soj9.noSQLTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoSqlTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoSqlTestApplication.class, args);
	}

}
