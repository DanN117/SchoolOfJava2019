package soj9.noSQLTest.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import soj9.noSQLTest.model.Cast;

@Repository
public interface CastRepository extends MongoRepository<Cast,String> {
}
