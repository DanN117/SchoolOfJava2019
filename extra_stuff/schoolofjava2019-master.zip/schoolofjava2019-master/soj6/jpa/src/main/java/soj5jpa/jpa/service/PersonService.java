package soj5jpa.jpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import soj5jpa.jpa.entities.Person;
import soj5jpa.jpa.repository.PersonRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PersonService {

    final PersonRepository personRepository;
    @Autowired
    public PersonService(PersonRepository personRepository){
        this.personRepository=personRepository;
    }

    public List<Person> getPeople(){
        return personRepository.findAll();
    }
    public Optional<Person> getPersonById(int id){

        return personRepository.findById(id);
    }

}
