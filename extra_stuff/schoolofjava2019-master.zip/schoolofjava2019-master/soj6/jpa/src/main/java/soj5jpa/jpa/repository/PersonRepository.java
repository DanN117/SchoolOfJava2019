package soj5jpa.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.stereotype.Repository;
import soj5jpa.jpa.entities.Person;

@Repository
public interface PersonRepository extends JpaRepository<Person, Integer> {

}
