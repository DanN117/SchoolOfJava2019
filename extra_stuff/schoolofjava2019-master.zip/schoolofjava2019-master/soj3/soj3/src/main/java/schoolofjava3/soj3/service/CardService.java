package schoolofjava3.soj3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import schoolofjava3.soj3.model.Card;
import schoolofjava3.soj3.repository.CardRepository;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Service
public class CardService {
    private CardRepository cardRepository;

    @Autowired
    public CardService(CardRepository cardRepository) {
        this.cardRepository = cardRepository;
    }

    public void addCard(Card card , HttpServletResponse response){

        if(card.getOwnerName()!=null){

            cardRepository.addCard(card);

        }else {
            response.setStatus(403);
        }
    }
    public List <Card> getAllCards(){
       return cardRepository.getCards();
    }

}
