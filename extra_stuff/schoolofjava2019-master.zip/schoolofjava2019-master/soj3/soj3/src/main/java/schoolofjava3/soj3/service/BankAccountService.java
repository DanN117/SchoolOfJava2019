package schoolofjava3.soj3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import schoolofjava3.soj3.model.BankAccount;
import schoolofjava3.soj3.repository.BankAccountRepository;

import javax.servlet.http.HttpServletResponse;

@Service
public class BankAccountService {

    private BankAccountRepository bankAccountRepository;

    @Autowired
    public BankAccountService(BankAccountRepository bankAccountRepository) {
        this.bankAccountRepository = bankAccountRepository;
    }

    public void addBankAccount(BankAccount bankAccount , HttpServletResponse response){

        if(bankAccount.getBalance()>50){

            bankAccountRepository.addBankAccount(bankAccount);

        }else {
            response.setStatus(403);
        }
        }


    }

