package schoolofjava3.soj3.repository;

import org.springframework.stereotype.Repository;
import schoolofjava3.soj3.model.BankAccount;

import java.util.ArrayList;
import java.util.List;

@Repository
public class BankAccountRepository {

    List<BankAccount> bankAccounts=new ArrayList<>();

    public void addBankAccount(BankAccount bankAccount){
        bankAccounts.add(bankAccount);

    }

    public List<BankAccount> getBankAccounts(){
        return bankAccounts;
    }




}
