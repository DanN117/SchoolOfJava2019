package schoolofjava3.soj3.repository;

import org.springframework.stereotype.Repository;
import schoolofjava3.soj3.model.Card;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CardRepository {

    List <Card> listCards=new ArrayList<>();

    public void addCard(Card card){
        listCards.add(card);

    }

    public List<Card> getCards(){
        return listCards;
    }
}
