package schoolofjava3.soj3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Soj3Application {

	public static void main(String[] args) {
		SpringApplication.run(Soj3Application.class, args);
	}

}
