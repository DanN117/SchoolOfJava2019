package schoolofjava3.soj3.model;

public class Card {
    private String ownerName;
    private String cardNumber;
    private String Id;

    public String getId() {
        return Id;
    }

    @Override
    public String toString() {
        return "Card{" +
                "ownerName='" + ownerName + '\'' +
                ", cardNumber='" + cardNumber + '\'' +
                ", Id='" + Id + '\'' +
                '}';
    }

    public void setId(String id) {
        Id = id;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }
}
