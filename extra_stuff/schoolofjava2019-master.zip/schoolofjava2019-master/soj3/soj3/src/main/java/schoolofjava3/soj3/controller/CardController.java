package schoolofjava3.soj3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import schoolofjava3.soj3.model.Card;
import schoolofjava3.soj3.service.CardService;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@RestController
public class CardController {
    private CardService cardService;

    @Autowired
    public CardController(CardService cardService) {
        this.cardService = cardService;
    }

    @PostMapping(path= "/add/card")
    public void addCard(@RequestBody Card card, HttpServletResponse response) {
        cardService.addCard(card,response);
    }

    @GetMapping(path = "/retrieve/accounts")
    public List<Card> getAllCards (){
        return cardService.getAllCards();
    }


}
