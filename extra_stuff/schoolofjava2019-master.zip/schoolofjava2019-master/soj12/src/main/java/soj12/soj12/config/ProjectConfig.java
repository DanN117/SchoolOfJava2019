package soj12.soj12.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import java.util.Arrays;
import java.util.Collection;

@Configuration
public class ProjectConfig  extends WebSecurityConfigurerAdapter {
    //primul lucru pe care trebuie sa l face e sa specificam metoda prin care se face accesul

    //Componenta care se ocupa de managementul userilor: = Autentificarea prin user detail service

    //trebuie sa ii spun lu spring service cum sa decodeze parola
    //parola este criptata intotdeauna-intr-o baza de date parola este hashuita
    //hashing =one way; encriptare=both ways



        public  PasswordEncoder passwordEncoder(){
            return NoOpPasswordEncoder.getInstance();

        }



    @Bean
    public UserDetailsService userDetailsServiceBean() throws Exception {
     /*   UserDetails u=new UserDetails(){ //contractul pe care il folosim ca sa descriem usersul
            @Override
            //grantedauthority= pt abstractizare
            //user detail=interfata nu obiect
            //autorith=interfata nu string
            public Collection<? extends GrantedAuthority> getAuthorities() {
                //return Arrays.asList(()->"ADMIN");
                GrantedAuthority a=()->"ADMIN";
                return Arrays.asList(a);
            }

            @Override
            public String getPassword() {
                return "12345";
            }

            @Override
            public String getUsername() {
                return "bill";
            }

            @Override
            public boolean isAccountNonExpired() {
                return true;
            }

            @Override
            public boolean isAccountNonLocked() {
                return true;
            }

            @Override
            public boolean isCredentialsNonExpired() {
                return true;
            }

            @Override
            public boolean isEnabled() {
                return true;
            }
        };
        UserDetailsService us= username->u; //contractul pe care l folosim sa incarcaram userul din baza =cauta userul

        //granted autorithy=ala care spune ca un user e admin sau orice altceva etc
      */
        //userdetailsservice abstractizeaza doar luarea de useri
        // nu si adaugarea de useri
        UserDetailsService us= new InMemoryUserDetailsManager();

        UserDetails user1=User.withUsername("bill").password("12345").build();
        UserDetails user2=User.withUsername("john")
                .password("12345").authorities("ADMIN").build();
       // nuj de ce nu merge dar vezi acasa
        //  us.createUser(user1);
       // us.createUser(user2);
        //InMemoryUserDetailsManager us=new InMemoryUserDetailsManager();

        return us;

    }

    //pe ce endpointuri securizam si cum facem securizarea =autorizarea
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.httpBasic();
        //ttp.authorizeRequests().anyRequest().permitAll();
        // in acest mod toate endpointurile sunt accesibile
       // http.authorizeRequests().anyRequest().authenticated();
      //Ant matchers-ii pot da direct calea sau pot sa ii dau calea si requestul sau pot sa ii dau toate caile
        //Ant /hello /hello/* /hello/** /hello/*/** /*/hello/**
        http.authorizeRequests().antMatchers("/hello").access("hasAutority('ADMIN')")
                .anyRequest().permitAll();

    }


}
