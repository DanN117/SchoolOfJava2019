export interface Movie {
    id?: number;
    title: string;
    genre: string;
}