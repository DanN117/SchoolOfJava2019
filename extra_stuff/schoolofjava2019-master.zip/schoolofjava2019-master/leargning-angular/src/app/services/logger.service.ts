import { Injectable } from '@angular/core';

@Injectable()
export class LoggerService{

private loggedMessages=0;



public logMessage(message:string){
    console.log(message);
    this.loggedMessages++;
}
public resetLoggedMessages(){
    this.loggedMessages=0;
}



}