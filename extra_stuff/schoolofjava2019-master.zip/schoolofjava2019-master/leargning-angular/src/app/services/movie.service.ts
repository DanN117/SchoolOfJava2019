import { Injectable } from '@angular/core';
import { LoggerService } from './logger.service';

import { Observable, ReplaySubject } from 'rxjs';
import { Movie } from '../movie/movie.model';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class MovieService{

    listOfMovies: Array<Movie>=[];
    listOfMoviesSubject: ReplaySubject<Array<Movie>>=new ReplaySubject(1);
    listOfMoviesSubject$=this.listOfMoviesSubject.asObservable();
    serverUrl='http://localhost:8080/movies/';

    constructor(private loggerService:LoggerService, private httpClient:HttpClient){






    }

    public loadAllMoviesWithSubject(){
        this.httpClient.get<Array<Movie>>(this.serverUrl).subscribe(
            value=>{
                this.listOfMovies=value;
                this.listOfMoviesSubject.next(this.listOfMovies);
            },
            error1=>{
                this.listOfMovies=[];
                this.listOfMoviesSubject.next(this.listOfMovies);
            },
            ()=>{});

            
        
    }

    public loadAllMovies():Observable<Array<Movie>>{
        this.loggerService.logMessage('loading all movies');
        return  this.httpClient.get<Array<Movie>>(this.serverUrl);
    }
    public removeMovie(){
        this.loggerService.logMessage('removing movie');
    }
    public createMovie(name:string, genre:string){
        this.loggerService.logMessage('creating movie');
    }
}