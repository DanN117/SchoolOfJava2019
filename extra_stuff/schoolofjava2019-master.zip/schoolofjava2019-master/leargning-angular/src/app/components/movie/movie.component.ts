import { Component, OnInit } from "@angular/core";
import { MovieService } from 'src/app/services/movie.service';
import { LoggerService } from 'src/app/services/logger.service';
import { Movie } from 'src/app/movie/movie.model';
import { Observable } from 'rxjs';


@Component({
    selector: 'app-movie',
    templateUrl: 'movie.component.html',
    styleUrls:['movie.component.css']
})
export class MovieComponent implements OnInit{
    loggerCount:number;
    allMovies:Array<Movie>=[];
    allMoviesLoadedWithSubject$:Observable<Array<Movie>>;

    constructor(private movieService:MovieService, private loggerService:LoggerService){
        
        loggerService.loggedMessagesSubject$.subscribe(value=>{this.loggerCount=value;
        });
        this.allMoviesLoadedWithSubject$=this.movieService.listOfMoviesSubject$;
    }
    ngOnInit():void{
       // this.movieService.loadAllMovies();
    }

    loadMovies(){
        this.movieService.loadAllMovies().subscribe(value=>{
            this.allMovies=value;

        }, error1=>{
            console.error('could not load movies->first time will be cors excepting');
        }, ()=>{
            console.log('subscription finished');
        }

        );
    }
    loadMoviesWithSubject(){
        this.movieService.loadAllMoviesWithSubject();
    }
    refreshCount(){
        this.loggerService.resetLoggedMessages();
    }
}