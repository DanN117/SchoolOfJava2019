import { Component, Input, EventEmitter, Output, OnInit, OnChanges } from "@angular/core";

@Component({
    selector:'app-product-card',
    templateUrl:'product-card.component.html',
    styleUrls:['product-card.component.css']
})
export class ProductCardComponent implements OnInit, OnChanges{
    ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
       console.log(changes);
       console.log('From NgOnChanges in Product Card')
    }
    ngOnInit(): void {
        console.log('From Product Card On Init!');
    }
    
    @Input()
    productName:string;
    
    @Input()
    productDescription:string;

    @Input()
    price:number;

    @Output()
    priceChange:EventEmitter<number>=new EventEmitter();

    @Output()
    productNameChanged: EventEmitter<string>=new EventEmitter();

    @Output()
    productDescriptionChanged:EventEmitter<string>=new EventEmitter();

    resetValues(): void{
        const defaultValue='default value'
        this.productName=defaultValue;
        this.productDescription=defaultValue;

        //emit values
        this.productNameChanged.emit(defaultValue);
        this.productDescriptionChanged.emit(defaultValue);
        this.price=0;
        this.priceChange.emit(0);
    }
}