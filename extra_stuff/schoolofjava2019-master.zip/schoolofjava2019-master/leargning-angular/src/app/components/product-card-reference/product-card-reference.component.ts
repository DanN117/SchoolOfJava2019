import { Component, Input, OnChanges } from "@angular/core";
import { Product } from './product.model';
import { TouchSequence } from 'selenium-webdriver';

@Component({
    selector:'app-product-card-reference',
    templateUrl:'product-card-reference.component.html',
    styleUrls:['product-card-reference.component.css']
})

export class ProductCardReference implements OnChanges{
    ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
        console.log('FROM CARD REFERENCE');
        console.log(changes);
    }

    @Input()
    product: Product;

    incrementPrice(): void {
        this.product.price=this.product.price+1;
       
    }

}
