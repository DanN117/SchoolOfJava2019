import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import {MatToolbarModule, MatButtonModule} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ShopComponent } from './components/shop/shop.component';
import { ProductCardComponent } from './components/product-card/product-card.component';
import { ProductCardReference } from './components/product-card-reference/product-card-reference.component';
import { AppHoverDirective } from './directives/app-hover.directive';
import { MovieComponent } from './components/movie/movie.component';
import { LoggerService } from './services/logger.service';
import { MovieService } from './services/movie.service';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    AppComponent, 
    ShopComponent,
    ProductCardComponent,
    ProductCardReference,
    AppHoverDirective,
    MovieComponent
  
  ],
  imports: [
    BrowserModule,
    MatToolbarModule,
    FlexLayoutModule,
    MatToolbarModule,
    MatButtonModule,
    HttpClientModule
   
    

  ],
  exports: [],
  providers: [
    MovieService,
    LoggerService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
