package main;

import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        Person p=new Person();
        p.sayHello("Bill");

       //exemplu de singleton in jdk Runtime.getRuntime().availableProcessors();
        //exemplu de builder: StringBuilder
        /*Locale loc=new Locale.Builder()
                .setLanguage("en")
                .setRegion("Us")
                .build();
        */

        //exemplu de factory method
        //Executors;
    }
}
