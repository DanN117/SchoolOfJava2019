package main;

import api.Hello;
import impl.HelloEnd;

public class Person {

    private Hello hello;

    public Person(){
        this.hello=Hello.build();

    }

    public void sayHello(String name){
       String output= hello.hello(name);
       System.out.println(output);
    }
}
