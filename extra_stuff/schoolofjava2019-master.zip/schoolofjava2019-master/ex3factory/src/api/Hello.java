package api;

import impl.HelloEs;

//interfata este folosita pt a realiza un contract
//reprezinta un contract intre 2 parti
public interface Hello {
    public String hello(String name);
    public static Hello build(){
        return new HelloEs();
    }
}
