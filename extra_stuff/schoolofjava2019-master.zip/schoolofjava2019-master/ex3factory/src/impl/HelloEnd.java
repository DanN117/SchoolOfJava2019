package impl;

import api.Hello;

public class HelloEnd implements Hello {

    @Override
    public String hello(String name){
        return "Hello" + name;
    }
}
