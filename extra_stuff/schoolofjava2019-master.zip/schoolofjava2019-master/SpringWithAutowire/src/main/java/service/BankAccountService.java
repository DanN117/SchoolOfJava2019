package service;


import model.BankAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.BankAccountRepository;
import repository.TransactionRepository;

//se ocupa de toate procesarile pe care le faci intr o anumita metoda

@Service
public class BankAccountService {

    @Autowired
    private BankAccountRepository bankAccountRepository;

    public void addBankAccount(BankAccount bankAccount){
        bankAccountRepository.insertBankAccount(bankAccount);
    }

    public void transferMoney(String fromIban, String toIban, double amount){

        BankAccount fromBankAccount=bankAccountRepository.getBankAccount(fromIban);
        BankAccount toBankAccount=bankAccountRepository.getBankAccount((toIban));
        if(fromBankAccount!=null && toBankAccount !=null){

           double firstBankAccountBalance=
            fromBankAccount.getBalance();
           double secondBankAccountBalance= toBankAccount.getBalance();
           //se vor modifica si obiectele din lista

            fromBankAccount.setBalance(toBankAccount.getBalance()-amount);
            toBankAccount.setBalance(toBankAccount.getBalance()+amount);

        }
    }


}
