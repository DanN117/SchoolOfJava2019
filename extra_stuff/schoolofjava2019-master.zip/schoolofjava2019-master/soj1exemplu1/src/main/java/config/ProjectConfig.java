package config;

import objects.Pisica;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration //facem ca aceasta clasa sa fie o clasa de configurare
public class ProjectConfig {
    @Bean
    //instanta returnata de aceasta metoda o sa fie in contextul
    //aceasta metoda nu reprezinta o actiune ci doar creaza o instanta de tipul cat in context
    @Scope("prototype")
    public Pisica pisica(){
        Pisica c=new Pisica();
        c.name="Tom";
        return c;
    }
}
