package main;

import config.ProjectConfig;
import objects.Pisica;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String [] args){

        try(AnnotationConfigApplicationContext context =
                    new AnnotationConfigApplicationContext(ProjectConfig.class)){
            Pisica c1=context.getBean(Pisica.class);
            Pisica c2=context.getBean(Pisica.class);
            System.out.println(c1);
            System.out.println(c2);
        }
    }
}
