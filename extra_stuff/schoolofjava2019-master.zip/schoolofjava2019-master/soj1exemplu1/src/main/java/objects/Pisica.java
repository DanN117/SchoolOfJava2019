package objects;

public class Pisica {
    public String name;

}
