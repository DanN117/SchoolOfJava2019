package exemplu;

public class MySingleton2 {

    private static MySingleton2 singleton;

    private MySingleton2(){

    }
    //in acest moment stiu sigur ca firele de executie vor sta
    //la coada
    //este o solutie proasta deoarece am sincronizat absolut toate
    //apelurile
    //singurul apel pt care eu vreau sa sincronizez este primul
    //am introdus latenta nenecesara
   /* public static synchronized  MySingleton2 getInstance(){
        if(singleton==null){
            singleton=new MySingleton2();
        }
        return singleton;
    }
    */
    //daca variabila este nula sincronizez blocul de instructiuni si
    //apoi pun conditia de sincronizare inainte de instantiere
    public static MySingleton2 getInstance() {
        if (singleton == null) {
            synchronized (MySingleton2.class) { //referinta catre prototipul clasei
                if (singleton == null) {
                    singleton = new MySingleton2();
                }
                return singleton;
            }
        }
    }

}
