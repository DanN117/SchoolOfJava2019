package exemplu;

public class Main {
    public static void main(String[] args) {
        MySingleton1 s1=MySingleton1.getInstance();
    }
}
