package exemplu;

public class MySingleton1 {

    private static MySingleton1 singleton;

    private MySingleton1(){

    }
    //aceasta varianta nu e thread safe
    // (daca sunt mai multe threaduri paralele, ele pot apela
    // in acelasi moment getInstance si s-ar putea crea
    // 3 instante de Singleton
    public static MySingleton1 getInstance(){
        if(singleton==null){
            singleton=new MySingleton1();
        }
        return singleton;
    }

}
