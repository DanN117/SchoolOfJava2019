package demo.soje16resource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SojE16ResourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SojE16ResourceApplication.class, args);
	}

}
