package repository;

import entities.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public interface PersonRepository extends JpaRepository<Person,Integer> {

   // @Autowired
   // EntityManager entityManager;
    //acel operator care imi aduce si imi face operatiile pe baza de date

  //  public List<Person> getPeople(){
    //    List<Person> personList=entityManager.createQuery(query).getResultList();
    //    return personList;
   // }
}
