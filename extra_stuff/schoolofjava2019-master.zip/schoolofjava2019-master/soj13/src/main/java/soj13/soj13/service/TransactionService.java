package soj13.soj13.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import soj13.soj13.entity.Transaction;
import soj13.soj13.repository.TransactionRepository;

@Service
public class TransactionService {
    @Autowired
    private TransactionRepository transactionRepository;

    public void addTransaction(Transaction transaction){
        if(transaction==null){
            throw new IllegalArgumentException("Transaction cannot be null!");
        }
        if(transaction.getAmount()<0) {
            throw new IllegalArgumentException("Amount cannot be negative");
        }
        transactionRepository.addTransaction(transaction);
    }
    public Transaction getTransactionById(long id){
        return transactionRepository.getTransactionById(id);
    }
}
