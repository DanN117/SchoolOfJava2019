package soj13.soj13.Controller;

import org.apache.coyote.Response;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;
import soj13.soj13.Soj13Application;
import soj13.soj13.entity.Transaction;

import javax.swing.*;

import static org.junit.Assert.*;

//pentru a ne porni serverul separat, specificam run with:
@RunWith(SpringRunner.class)
//o alta metoda
@SpringBootTest
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = { Soj13Application.class })
//@WebAppConfiguration
public class TransactionControllerTest {

    @MockBean //diferenta dintre mock si mockbean este ca mock ul este pt testele unitare si preia functionalitatea metodei mock din interiorul clasei mock
                //mockbean ul face mock uirea tuturor contextelor din spring
    private RestTemplate restTemplate;

    @MockBean
    private TransactionController transactionController;

    @Test
    public void testEndPointTest(){
        String url="http://localhost:8080/test";
        ResponseEntity<String> responseEntity= restTemplate.getForEntity(url, String.class);
                //restTemplate.exchange(url, HttpMethod.GET, null,String.class);
        Assert.assertEquals("I'm ok",responseEntity.toString());
    }

    @Test
    public void addTransactionTest(){
        String  url="http://localhost:8080/post";

        HttpEntity<Transaction> entity=new HttpEntity<>(transaction);
        ResponseEntity<String> responseEntity=restTemplate.exchange(url, HttpMethod.POST,entity, String.class);
    }




}