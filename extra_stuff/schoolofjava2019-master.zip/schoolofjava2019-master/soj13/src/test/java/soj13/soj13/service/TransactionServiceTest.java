package soj13.soj13.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import soj13.soj13.entity.Transaction;
import soj13.soj13.repository.TransactionRepository;

import static org.junit.Assert.*;
@RunWith(MockitoJUnitRunner.class)
public class TransactionServiceTest {

    private static final long ID = 100L;
    @InjectMocks // doar pe clasa pe care o testam
    private TransactionService transactionService;


    @Mock // punem pe toate componentele clasei pe care o testam
    private TransactionRepository transactionRepository;

    Transaction transaction;

    @Before
    public void setUp() { // codul de aici se apeleaza inaintea fiecarui test

        transaction = new Transaction();

        transaction.setId(ID);
        transaction.setAmount(30.0);
        transaction.setName("John");
    }

    @Test //sugeram compilerului ca e o metoda de test
    public void testAddTransaction() {


        transactionService.addTransaction(transaction);
        Mockito.verify(transactionRepository, Mockito.times(1)).addTransaction(transaction);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddTransactionWhenInputIsNullThrowAnException() {

        transactionService.addTransaction(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddTransactionWhenInputIsInvalidThrowAnException() {
        Transaction transaction = new Transaction();
        transaction.setId(100);
        transaction.setAmount(-30.0);
        transaction.setName("John");

        transactionService.addTransaction(transaction);

    }

    @Test
    public void testGetTransaction() {
        Mockito.when(transactionRepository.getTransactionById(ID))
                .thenReturn(transaction);

        Transaction actualTransaction = transactionService.getTransactionById(ID);
        assertEquals(transaction.getId(), actualTransaction.getId());
        assertEquals(transaction.getAmount(), actualTransaction.getAmount(), 10);
        assertEquals(transaction.getName(), actualTransaction.getName());

    }
}