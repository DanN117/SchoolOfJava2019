package main;

public class Main {
    public static void main(String[] args) {
        Subject s=new Subject();

        s.addMyListener(()-> System.out.println("BAU"));
        s.addMyListener(()-> System.out.println("BAU1"));
        s.addMyListener(()-> System.out.println("BAU2"));
        s.addMyListener(()-> System.out.println("BAU3"));
        s.addMyListener(()-> System.out.println("BAU4"));
        s.addMyListener(()-> System.out.println("BAU5"));
        s.addMyListener(()-> System.out.println("BAU6"));
        s.event();
    }
}
