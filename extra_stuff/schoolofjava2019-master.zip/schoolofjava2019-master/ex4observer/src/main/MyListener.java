package main;

public interface MyListener {

    void somethingHappened();

}
