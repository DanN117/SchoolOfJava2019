package demo.soje16authorizationserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SojE16AuthorizationserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SojE16AuthorizationserverApplication.class, args);
	}

}
