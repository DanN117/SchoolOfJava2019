package demo.soje16authorizationserver.repositories;


import demo.soje16authorizationserver.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.swing.text.html.Option;
import java.util.Optional;


public interface UserRepository extends JpaRepository<User,Integer> {
    Optional<Object> findUserByUsername(String username);
}
